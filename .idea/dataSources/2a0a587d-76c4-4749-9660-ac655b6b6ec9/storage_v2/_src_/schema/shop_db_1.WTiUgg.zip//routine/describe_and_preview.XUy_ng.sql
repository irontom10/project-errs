create
    definer = errs_user@`%` procedure describe_and_preview()
BEGIN
  DECLARE done INT DEFAULT 0;
  DECLARE tbl VARCHAR(255);
  DECLARE cur CURSOR FOR
    SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA = 'shop_db_1';
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

  OPEN cur;

  read_loop: LOOP
    FETCH cur INTO tbl;
    IF done THEN
      LEAVE read_loop;
    END IF;

    -- Print which table we're on
    SELECT CONCAT('=== ', tbl, ' ===') AS table_name;

    -- Describe table
    SET @sql := CONCAT('DESCRIBE `', tbl, '`;');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

    -- Show 2 sample rows
    SET @sql := CONCAT('SELECT * FROM `', tbl, '` LIMIT 2;');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

  END LOOP;

  CLOSE cur;
END;

